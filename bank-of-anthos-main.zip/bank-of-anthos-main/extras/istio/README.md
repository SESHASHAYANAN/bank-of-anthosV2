# Istio manifests

To use, simply `kubectl apply -f frontend-ingress.yaml` on top of a deployment
of Bank of Anthos. You can then access the frontend through the IngressGateway.